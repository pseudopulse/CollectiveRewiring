# 1.1.3
- Increased distance for targeting allies with Operator drone abilities.
- Fixed "Unique Drones Inherit Items" preventing them from being upgraded.
- SPEX now has the same damage requirements as downed Solus Heart.

# 1.1.2
- Fixed some missing tags in the drone inherit blacklist.

# 1.1.1
- Fixed Operator passive description gaining sentience. It will no longer cry for help.

# 1.1.0
- Reduced Operator's Nano-Bugged damage increase from 100% to 50%.
- Operator's unique drones now inherit items.
- Neutronium Weight now always returns directly to you, even upon leaving the stage.
- Enemies can no longer pass Neutronium Weight to non-players.
- Neutronium Weight now deals 100% TOTAL damage when passed.
- Fixed networking issue with drone cooldowns.
- Added config to have Operator's keybind only cycle instead of also grabbing.

# 1.0.0
- released